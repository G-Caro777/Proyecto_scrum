<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra realizada</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery-3.6.1.js"></script>
</head>
<body>
    <?php include 'menu.php' ?>
    <div class="container">
        <div class="row">
            <div class="col-11">

<div class="card text-center">
  <div class="card-header">
.
  </div>
  <div class="card-body">
  <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/>
  </svg><br><br>    
    <h2 class="card-title">¡Tu compra ha sido realizada con éxito! </h2><br>
    <h5 class="card-text">El numero de tu pedido es #0027</h5><br>
    <a href="index.php" class="btn btn-primary btn-lg">Volver ala pagina principal</a>
  </div>
  <div class="card-footer text-muted">
  </div>
</div>
<i class="bi bi-check-circle"></i>
<footer class="text-center">
        <hr>
        2022 &copy; Tienda
    </footer>
    <script src="js/bootstrap.js"></script>
</body>
</html>